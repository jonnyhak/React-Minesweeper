import React from 'react';


export default class Tile extends React.Component {
    constructor(props) {
        super(props);
        this.handleClick = this.handleClick.bind(this);
    }

    handleClick(e) {
        const flagged = e.altKey ? true : false;
        this.props.update(this.props.tile, flagged) 
    }

    render() {
        const tile = this.props.tile;
        let name = "unexplored";
        let icon = "";
        
        if (tile.flagged){
            name = "flagged";
            icon = "🚩";
        } else if (tile.explored) {
            if (tile.bombed) {
                name = "bombed";
                icon = "💣";
            } else {
                name = "explored";
                let count = tile.adjacentBombCount();
                icon = count > 0 ? count : "";
            }
        } 
        name = `tile ${name}`

        return (
            <div className={name} onClick={this.handleClick}>
                {icon}
            </div>
        )
    }
}