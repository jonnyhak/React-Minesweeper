import React from 'react';
import Board from './board.jsx';
import * as Minesweeper from './minesweeper.js';

export default class Game extends React.Component {
    constructor(props) {
        super(props);

        const board = new Minesweeper.Board(10, 12);
        
        // @a = {0:asdasd}
        this.state = {
            board: board
        };

        // state.lost = {}.lost()
        // this.lost = Game.lost

        this.updateGame = this.updateGame.bind(this);
        this.endGame = this.endGame.bind(this);
    }

    updateGame(tile, flagged) {
        if (flagged) {
            tile.toggleFlag()
        } else {
            tile.explore()
        }

        this.setState( {board: this.state.board} )
    }

    endGame() {
        const board = new Minesweeper.Board(10, 12);
        this.setState( {board: board})
    }
    
    render() {
        let end;
        if (this.state.board.lost() || this.state.board.won()) {
            const text = this.state.board.won() ? "You won!" : "You lost!";
            end = 
            <div className='modal-screen'>
                <div className='modal-content'>
                    <p>{text}</p>
                    <button onClick={this.endGame}>Play again!</button>
                </div>
            </div>

        }

        return (
            <>
            <h1> Minesweeper </h1>
                <p>Click to explore a tile.</p>
                <p>Alt + click to flag a tile.</p>
                <Board
                board={this.state.board}
                update={this.updateGame}
                />
                {end}
            </>
        )
    }
 }
