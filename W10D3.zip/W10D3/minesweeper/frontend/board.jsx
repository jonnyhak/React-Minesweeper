import React from 'react';
import Tile from './tile';

export default class Board extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        const divRows = this.props.board.grid.map((row, i) => {
            return <div className="row" key={`row-${i}`}>
                    {row.map((tile, j) => {
                        return <Tile
                            key={`tile-${i}-${j}`}
                            tile={tile}
                            update={this.props.update} 
                        />
                    })}
                </div>
        })
        return (
            <div className="board">
                {divRows}
            </div>
        )
    }
}